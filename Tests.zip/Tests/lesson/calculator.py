def calculator(ecpression):
    allowed = '+-/*'
    if not any(sign in ecpression for sign in allowed):
        raise ValueError(f'Выражение должно содержать хотя бы один знак ({allowed})')
    for sign in allowed:
        if sign in ecpression:
            try:
                left, right = ecpression.split(sign)
                left, right = int(left), int(right)
                if sign == '+':
                    return left + right
                elif sign == '-':
                    return left - right
                elif sign == '*':
                    return left * right
                elif sign == '/':
                    return left / right
            except (ValueError, TypeError):
                raise ValueError('выражение должно содержать 2 целых числа и 1 знак')


if __name__ == '__main__':
    print(calculator('10/5'))
