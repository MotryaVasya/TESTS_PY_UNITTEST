from unittest import TestCase, main
from lesson.calculator import calculator


class CalculatorTest(TestCase):
    def test_plus(self):
        self.assertEquals(calculator('2+2'), 4)

    def test_minus(self):
        self.assertEquals(calculator('3-1'), 2)

    def test_multi(self):
        self.assertEquals(calculator('4*4'), 16)

if __name__ == '__main__':
    main()
